
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'wschaeferiii',
  applicationName: 'softgiving-mock-payment-recorder',
  appUid: 'y14BGhW7xvmBZ2xGPz',
  orgUid: '6e074423-1b17-428e-a447-fd69ca82b9db',
  deploymentUid: 'c671e22c-3cde-42c1-965b-6cf07a2c3649',
  serviceName: 'softgiving-assignment',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.5.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'softgiving-assignment-dev-mockPayment', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.mockPayment, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}